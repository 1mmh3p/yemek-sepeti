﻿//------------------------------------------------------------------------------
// <otomatik olarak oluşturulmuş>
//     Bu kod bir araç tarafından oluşturuldu.
//
//     Bu dosyada yapılacak değişiklikler hatalı davranışa neden olabilir ve
//     kod tekrar üretildi. 
// </otomatik olarak oluşturulmuş>
//------------------------------------------------------------------------------

namespace yemek_sepeti
{


    public partial class Iletisim_Satici
    {

        /// <summary>
        /// form1 denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;

        /// <summary>
        /// txt_nickname denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txt_nickname;

        /// <summary>
        /// txt_mail denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txt_mail;

        /// <summary>
        /// txt_message denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txt_message;

        /// <summary>
        /// btn_msgGonder denetimi.
        /// </summary>
        /// <remarks>
        /// Otomatik olarak oluşturulan alan.
        /// Değiştirmek için, alan bildirimini tasarımcı dosyasından arka plan kod dosyasına taşıyın.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button btn_msgGonder;
    }
}
