﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace yemek_sepeti.classes
{
    public class SQLConnection
    {
        public SqlConnection Baglan()
        {
            SqlConnection baglanti = new SqlConnection(@"Data Source=MUSTAFA;Initial Catalog=yemek_sepeti;Integrated Security=True;Encrypt=False");
            baglanti.Open();
            return baglanti;
        }
    }

    
}