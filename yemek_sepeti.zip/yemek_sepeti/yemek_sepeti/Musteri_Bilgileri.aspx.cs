﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class Musteri_Bilgileri : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false) //Sadece sayfa ilk yüklendiğinde çalışacak kısım.
            {
                if (Convert.ToBoolean(Session["isCustomer"]) == true) //Giris Yapan müşteri mi kontrol ediyoruz
                {
                    SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz

                    SqlCommand sqlCommand_KaydiGetir = new SqlCommand("select Musteri_KullaniciAdi,Musteri_IsimSoyisim,Musteri_Mail,Musteri_Tel,Musteri_Sehir,Musteri_Ilce,Musteri_Mahalle,Musteri_Sokak,Musteri_DaireNo,Musteri_Sifre,Musteri_DogumTarihi from tbl_musteriler where Musteri_KullaniciAdi = @PmusteriNickname", baglanti); //Kullanıcı adına göre müşterinin tüm bilgilerini getiriyoruz.
                    sqlCommand_KaydiGetir.Parameters.AddWithValue("@PmusteriNickname", Session["Nickname"].ToString());
                    SqlDataReader okuyucu = sqlCommand_KaydiGetir.ExecuteReader();
                    while (okuyucu.Read())
                    {//Gelen verileri textlere atıyoruz.
                        txt_nickname.Text = okuyucu[0].ToString();
                        txt_name.Text = okuyucu[1].ToString();
                        txt_mail.Text = okuyucu[2].ToString();
                        txt_tel.Text = okuyucu[3].ToString();
                        txt_sehir.Text = okuyucu[4].ToString();
                        txt_ilce.Text = okuyucu[5].ToString();
                        txt_mahalle.Text = okuyucu[6].ToString();
                        txt_sokak.Text = okuyucu[7].ToString();
                        txt_daireNo.Text = okuyucu[8].ToString();
                        txt_password.Text = okuyucu[9].ToString();
                        txt_dogumTarihi.Text = okuyucu[10].ToString();
                    }
                    okuyucu.Close();

                    SqlCommand sqlCommand_YasHesapla = new SqlCommand("select dbo.YasHesapla(@Pdogum_tarihi)", baglanti); //Kullanıcının yaşını hesaplıyoruz.
                    sqlCommand_YasHesapla.Parameters.AddWithValue("@Pdogum_tarihi", txt_dogumTarihi.Text);
                    SqlDataReader okuyucu1 = sqlCommand_YasHesapla.ExecuteReader();
                    while (okuyucu1.Read())
                    {//Yaşı ekrana yazdırıyoruz
                        txt_yas.Text = okuyucu1[0].ToString();
                    }
                    okuyucu1.Close();

                    baglanti.Close();
                }
                else
                {
                    Response.Redirect("Giris_Yap.aspx"); //Müşteri değilse giriş yapmaya gönderiyoruz.
                }
            }
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(txt_tel.Text != "" && txt_sehir.Text != "" && txt_ilce.Text != "" && txt_mahalle.Text != "" && txt_sokak.Text != "" && txt_daireNo.Text != "" && txt_password.Text != "") //Girdilerin doluluğunu kontrol ediyoruz.
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_KaydiGüncelle = new SqlCommand("update tbl_musteriler set Musteri_Sifre = @Psifre, Musteri_Tel=@Ptel, Musteri_Sehir = @Psehir, Musteri_Ilce = @Pilce, Musteri_Mahalle =@Pmahalle, Musteri_Sokak = @Psokak, Musteri_DaireNo = @Pno where Musteri_KullaniciAdi = @PmusteriNickname", baglanti); //Kullanıcı bilgilerini güncelliyoruz.
                sqlCommand_KaydiGüncelle.Parameters.AddWithValue("@Psifre", txt_password.Text);
                sqlCommand_KaydiGüncelle.Parameters.AddWithValue("@Ptel", txt_tel.Text);
                sqlCommand_KaydiGüncelle.Parameters.AddWithValue("@Psehir", txt_sehir.Text);
                sqlCommand_KaydiGüncelle.Parameters.AddWithValue("@Pilce", txt_ilce.Text);
                sqlCommand_KaydiGüncelle.Parameters.AddWithValue("@Pmahalle", txt_mahalle.Text);
                sqlCommand_KaydiGüncelle.Parameters.AddWithValue("@Psokak", txt_sokak.Text);
                sqlCommand_KaydiGüncelle.Parameters.AddWithValue("@Pno", txt_daireNo.Text);
                sqlCommand_KaydiGüncelle.Parameters.AddWithValue("@PmusteriNickname", Session["Nickname"].ToString());
                sqlCommand_KaydiGüncelle.ExecuteNonQuery();
                baglanti.Close();
                Response.Write("<script>alert('Güncelleme Başarılı');</script>"); //Ekrana başarılı yazdırıyoruz.
            }
            else
            {
                Response.Write("<script>alert('Eksik Veri Girişi Yaptınız');</script>"); //Ekrana veriler eksik yazdırıyoruz.
            }
        }
    }
}