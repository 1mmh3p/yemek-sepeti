﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class Siparisler_Satici : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isDealer"])) //Giris Yapan satıcı mı kontrol ediyoruz
            {
                SqlConnection baglanti = baglanti_cls.Baglan();
                SqlCommand sqlCommand_SiparisleriGetir = new SqlCommand("up_SiparişleriGetirSaticiyaGore @Ponay, @PsaticiKullaniciAdi", baglanti); //Satıcıya ait siparişleri listeliyoruz.
                sqlCommand_SiparisleriGetir.Parameters.AddWithValue("@PsaticiKullaniciAdi", Convert.ToString(Session["Nickname"]));
                sqlCommand_SiparisleriGetir.Parameters.AddWithValue("@Ponay", true);
                SqlDataReader okuyucu = sqlCommand_SiparisleriGetir.ExecuteReader();
                DataList1.DataSource = okuyucu;
                DataList1.DataBind(); //Verileri eşitlenir.
                okuyucu.Close();

                SqlCommand sqlCommand_SiparisleriSay = new SqlCommand("select dbo.SaticiSiparisSayisiHesapla(@PsaticiKullaniciAdi)", baglanti); //Kaç sipariş olduğunu hesaplıyoruz.
                sqlCommand_SiparisleriSay.Parameters.AddWithValue("@PsaticiKullaniciAdi", Convert.ToString(Session["Nickname"]));
                SqlDataReader okuyucu1 = sqlCommand_SiparisleriSay.ExecuteReader();
                while (okuyucu1.Read())
                {//Sipariş sayısını texte yazdırır.
                    lbl_siparisSayisi.Text = okuyucu1[0].ToString();
                }
                okuyucu1.Close();

                baglanti.Close();
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //Müşteri değilse giriş yapmaya gönderiyoruz.
            }
        }
    }
}