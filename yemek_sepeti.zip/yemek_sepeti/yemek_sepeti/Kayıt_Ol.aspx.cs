﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class Kayıt_Ol : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        string kayit_turu;
        public string secilen_sehir;

        public Dictionary<string, string> secilen_sehirID = new Dictionary<string, string>();
        public static Dictionary<string, string> secilen_ilceID = new Dictionary<string, string>();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)
            {
                cbox_tur.Items.Add("Şirket"); //İlk seçime müşteri ve şirketi ekledik
                cbox_tur.Items.Add("Müşteri");

                kayit_turu = cbox_tur.SelectedValue; //Seçileni kaydettik
                Label1.Text = kayit_turu + " Olarak işleme devam ediyorsunuz!"; //Ekrana yazdırdık

                cbox_ilce.Enabled = false; //bazı comboboxları kapattık.
                cbox_mahalle.Enabled = false;
                txt_sokak.Enabled = false;
                txt_daire.Enabled = false;
                txt_dogumTarihi.Enabled = false;

                txt_nickName.Text = "";
                txt_name.Text = "";
                txt_tel.Text = "";
                txt_password.Text = "";
                txt_mail.Text = "";
                cbox_ilce.Items.Clear();
                cbox_mahalle.Items.Clear();
                txt_sokak.Text = "";
                txt_daire.Text = "";
            }
            

            SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
            SqlCommand sqlCommand_Sehirleri_Getir = new SqlCommand("select Isim, SehirID from tbl_sehir_bilgileri where SehirID>=0 and SehirID<=81", baglanti); //Şehilerin hepsini comboxa ekledik.
            SqlDataReader okuyucu = sqlCommand_Sehirleri_Getir.ExecuteReader();
            while (okuyucu.Read())
            {
                cbox_sehir.Items.Add(okuyucu[0].ToString());
                secilen_sehirID.Add(okuyucu[0].ToString(), okuyucu[1].ToString()); //İlçe id si ve şehri yanyana dictionarye kaydettik
            }
            okuyucu.Close();
            baglanti.Close();
            

        }

        protected void cbox_tur_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btn_turKaydet_Click(object sender, EventArgs e)
        {
            
            kayit_turu = cbox_tur.SelectedValue;
            Label1.Text = kayit_turu + " Olarak işleme devam ediyorsunuz!";

            if (kayit_turu == "Şirket") //Şirket kaydı
            {
                cbox_ilce.Enabled = false;
                cbox_mahalle.Enabled = false;
                txt_sokak.Enabled = false;
                txt_daire.Enabled = false;
                txt_dogumTarihi.Enabled = false;
            }
            else //Müşteri kaydı
            {
                cbox_ilce.Enabled = true;
                cbox_mahalle.Enabled = true;
                txt_sokak.Enabled = true;
                txt_daire.Enabled = true;
                txt_dogumTarihi.Enabled = true;
            }
        }

        protected void btn_kayit_Click(object sender, EventArgs e) //Kayıt butonuna basınca olacaklar
        {
            kayit_turu = cbox_tur.SelectedValue; //Seçilen kayıt türünü getirdik
            if(kayit_turu == "Şirket" && txt_nickName.Text != "" && txt_name.Text != "" && txt_password.Text != "" && txt_mail.Text !="" && txt_tel.Text != "") //Şirketse ve boxlar doluysa
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                bool nickKontrol = true;
                SqlCommand sqlCommand_Satici_Kontrol = new SqlCommand("select Satici_KullaniciAdi from tbl_saticilar where Satici_KullaniciAdi = @Pnickname", baglanti); //Alınmaya çalışılan kullanıcı daha önce tabloya eklenmişse onu getiriyoruz.
                sqlCommand_Satici_Kontrol.Parameters.AddWithValue("@Pnickname",txt_nickName.Text);
                SqlDataReader okuyucu = sqlCommand_Satici_Kontrol.ExecuteReader();
                while (okuyucu.Read())
                {
                    nickKontrol = false; //Eğer veri gelirse nick kullanılmış diye değerini false yapıyoruz.
                }
                okuyucu.Close();

                if (nickKontrol) //Eğer kullanılmamışsa nicki
                {
                    SqlCommand sqlCommand_Satici_Kaydet = new SqlCommand("insert into tbl_saticilar(Satici_KullaniciAdi, Satici_İsmi, Satici_Şehir, Satici_Tel, Satici_Sifre, Satici_Mail) values (@Pnick, @Pname, @Psehir, @Ptel, @Psifre, @Pmail)", baglanti); //Satıcılar tablosuna kaydı ekliyoruz.

                    sqlCommand_Satici_Kaydet.Parameters.AddWithValue("@Pnick", txt_nickName.Text);
                    sqlCommand_Satici_Kaydet.Parameters.AddWithValue("@Pname", txt_name.Text);
                    sqlCommand_Satici_Kaydet.Parameters.AddWithValue("@Psehir", cbox_sehir.SelectedValue);
                    sqlCommand_Satici_Kaydet.Parameters.AddWithValue("@Ptel", txt_tel.Text);
                    sqlCommand_Satici_Kaydet.Parameters.AddWithValue("@Psifre", txt_password.Text);
                    sqlCommand_Satici_Kaydet.Parameters.AddWithValue("@Pmail", txt_mail.Text);

                    sqlCommand_Satici_Kaydet.ExecuteNonQuery();                    

                    Response.Write("<script>alert('Şirket Kaydı Başarılı');</script>"); //Kayıt başarılı yazdırıyoruz
                }
                else
                {
                    Response.Write("<script>alert('Bu kullanıcı adını kullanmazsınız');</script>");
                }
                baglanti.Close();
            }
            else if (kayit_turu == "Müşteri" && txt_nickName.Text != "" && txt_name.Text != "" && txt_password.Text != "" && txt_daire.Text != "" && txt_sokak.Text != "" && txt_dogumTarihi.Text != "") //Müşteriyse ve boxlar doluysa
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                string kullanici_yas = "0";
                bool nickKontrol = true;
                SqlCommand sqlCommand_Musteri_Kontrol = new SqlCommand("select Musteri_KullaniciAdi from tbl_musteriler where Musteri_KullaniciAdi = @Pnickname", baglanti); //Alınmaya çalışılan kullanıcı daha önce tabloya eklenmişse onu getiriyoruz.
                sqlCommand_Musteri_Kontrol.Parameters.AddWithValue("@Pnickname", txt_nickName.Text);
                SqlDataReader okuyucu = sqlCommand_Musteri_Kontrol.ExecuteReader();
                while (okuyucu.Read())
                {
                    nickKontrol = false; //Eğer veri gelirse nick kullanılmış diye değerini false yapıyoruz.
                }
                okuyucu.Close();

                SqlCommand sqlCommand_YasHesapla = new SqlCommand("select dbo.YasHesapla(@Pdogum_tarihi)", baglanti); //Müşterinin yaşını hesaplıyor ve getiriyoruz.
                sqlCommand_YasHesapla.Parameters.AddWithValue("@Pdogum_tarihi", txt_dogumTarihi.Text);
                SqlDataReader okuyucu1 = sqlCommand_YasHesapla.ExecuteReader();
                while (okuyucu1.Read())
                {
                    kullanici_yas = okuyucu1[0].ToString(); //Yaşını kaydediyoruz.
                }
                okuyucu1.Close();

                if (nickKontrol && (Convert.ToInt32(kullanici_yas)>=18)) //Yaşı 18 denn büyükse
                {
                    SqlCommand sqlCommand_Musteri_Kaydet = new SqlCommand("insert into tbl_musteriler(Musteri_KullaniciAdi, Musteri_Sifre, Musteri_IsimSoyisim, Musteri_Mail, Musteri_Tel, Musteri_Sehir, Musteri_Ilce, Musteri_Mahalle, Musteri_Sokak, Musteri_DaireNo,Musteri_DogumTarihi) values (@Pnick, @Psifre, @Pname, @Pmail, @Ptel, @Psehir, @Pilce, @Pmahalle, @Psokak, @PdaireNo, @PdogumTarihi)", baglanti); //Müşteriler tablosuna kaydı ekliyoruz.

                    sqlCommand_Musteri_Kaydet.Parameters.AddWithValue("@Pnick", txt_nickName.Text);
                    sqlCommand_Musteri_Kaydet.Parameters.AddWithValue("@Pname", txt_name.Text);
                    sqlCommand_Musteri_Kaydet.Parameters.AddWithValue("@Psehir", cbox_sehir.SelectedValue);
                    sqlCommand_Musteri_Kaydet.Parameters.AddWithValue("@Ptel", txt_tel.Text);
                    sqlCommand_Musteri_Kaydet.Parameters.AddWithValue("@Psifre", txt_password.Text);
                    sqlCommand_Musteri_Kaydet.Parameters.AddWithValue("@Pmail", txt_mail.Text);
                    sqlCommand_Musteri_Kaydet.Parameters.AddWithValue("@Pilce", cbox_ilce.SelectedValue);
                    sqlCommand_Musteri_Kaydet.Parameters.AddWithValue("@Pmahalle", cbox_mahalle.SelectedValue);
                    sqlCommand_Musteri_Kaydet.Parameters.AddWithValue("@Psokak", txt_sokak.Text);
                    sqlCommand_Musteri_Kaydet.Parameters.AddWithValue("@PdaireNo", txt_daire.Text);
                    sqlCommand_Musteri_Kaydet.Parameters.AddWithValue("@PdogumTarihi",txt_dogumTarihi.Text);
                    sqlCommand_Musteri_Kaydet.ExecuteNonQuery();

                    Response.Write("<script>alert('Müsteri Kaydı Başarılı.');</script>"); //Kayıt başarılı yazdırıyoruz
                }
                else
                {
                    Response.Write("<script>alert('Bu kullanıcı adını kullanmazsınız ya da 18 yaşını doldurmanız gerekiyor.');</script>");
                }
                
                baglanti.Close();

            }

            else
            {
                Response.Write("<script>alert('Eksik Veri Girişi Yaptınız!');</script>"); //Eksik veri girişi olduğunu söylüyoruz
            }
            
            
            txt_nickName.Text = "";
            txt_name.Text = "";
            txt_tel.Text = "";
            txt_password.Text = "";
            txt_mail.Text = "";
            cbox_ilce.Items.Clear();
            cbox_mahalle.Items.Clear();
            txt_sokak.Text = "";
            txt_daire.Text = "";
            
        }

        protected void btn_temizle_Click(object sender, EventArgs e)
        {
            Page.Response.Redirect(Page.Request.Url.ToString(), true); //Ekranı başa sarıyoruz ve her şeyi 0 lıyoruz.
        }

        protected void btn_sehirKaydet_Click(object sender, EventArgs e)
        {
            kayit_turu = cbox_tur.SelectedValue;
            if (kayit_turu == "Müşteri") //Müşteriyse
            {
                cbox_ilce.Items.Clear();
                secilen_ilceID.Clear();
                cbox_ilce.Enabled = true;

                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_Ilceleri_Getir = new SqlCommand("select Isim, MahalleID from tbl_sehir_bilgileri where AidiyetID = @PsehirID", baglanti); //Mahalle id yi getiriyoruz
                
                sqlCommand_Ilceleri_Getir.Parameters.AddWithValue("@PsehirID", secilen_sehirID[cbox_sehir.SelectedValue]);
                
                SqlDataReader okuyucu = sqlCommand_Ilceleri_Getir.ExecuteReader();
                while (okuyucu.Read())
                {
                    cbox_ilce.Items.Add(okuyucu[0].ToString()); //ilçeleri kaydediyoruz.
                    secilen_ilceID.Add(okuyucu[0].ToString(), okuyucu[1].ToString()); //İlçe ve idsini dictionary içine kaydediyoruz.
                }
                okuyucu.Close();
                baglanti.Close();

                //----------------------------------------

                cbox_mahalle.Items.Clear();
                cbox_mahalle.Enabled = true;

                SqlConnection baglanti2 = baglanti_cls.Baglan();
                SqlCommand sqlCommand_Mahalleleri_Getir = new SqlCommand("select Isim from tbl_sehir_bilgileri where AidiyetID = @PmahalleID", baglanti2); //Mahalleyi getiriyoruz

                sqlCommand_Mahalleleri_Getir.Parameters.AddWithValue("@PmahalleID", secilen_ilceID[cbox_ilce.SelectedValue]);

                SqlDataReader okuyucu2 = sqlCommand_Mahalleleri_Getir.ExecuteReader();
                while (okuyucu2.Read())
                {
                    cbox_mahalle.Items.Add(okuyucu2[0].ToString()); //Mahalleyi comboboxa ekliyoruz.
                }
                okuyucu.Close();
                baglanti.Close();
            }
        }

        protected void btn_ilceKaydet_Click(object sender, EventArgs e)
        {
            kayit_turu = cbox_tur.SelectedValue;

            if (kayit_turu == "Müşteri") //Müşteriyse
            {
                cbox_mahalle.Items.Clear();
                cbox_mahalle.Enabled = true;

                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_Mahalleleri_Getir = new SqlCommand("select Isim from tbl_sehir_bilgileri where AidiyetID = @PmahalleID", baglanti); //Mahalleyi getiriyoruz.

                sqlCommand_Mahalleleri_Getir.Parameters.AddWithValue("@PmahalleID", secilen_ilceID[cbox_ilce.SelectedValue]);

                SqlDataReader okuyucu = sqlCommand_Mahalleleri_Getir.ExecuteReader();
                while (okuyucu.Read())
                {
                    cbox_mahalle.Items.Add(okuyucu[0].ToString()); //Mahalleyi kaydediyoruz.
                }
                okuyucu.Close();
                baglanti.Close();
            }
        }

        protected void btn_mahalleKaydet_Click(object sender, EventArgs e)
        {
            if(cbox_tur.SelectedValue == "Müşteri") //Müşteriyse
            {
                txt_daire.Enabled = true; //daire ve sokak textini aktif ediyoruz.
                txt_sokak.Enabled = true;
            }
            
        }
    }
}