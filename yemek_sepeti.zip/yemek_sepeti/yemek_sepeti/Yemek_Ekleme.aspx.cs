﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class Yemek_Ekleme : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isDealer"]) == true) //Giris Yapan satıcı mı kontrol ediyoruz
            {
                if (Page.IsPostBack == false) //Sadece sayfa ilk yüklendiğinde çalışacak kısım.
                {
                    SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                    SqlCommand sqlCommand_YemekTuru = new SqlCommand("select distinct(Yemek_Türü) from tbl_yemekler", baglanti); //Farklı yemek türlerini getirir.

                    SqlDataReader okuyucu = sqlCommand_YemekTuru.ExecuteReader();

                    cbox_turSecimi.DataTextField = "Yemek_Türü"; //Text ve value değerlerinin nereden gelecek olduğunu gireriz.
                    cbox_turSecimi.DataValueField = "Yemek_Türü";

                    cbox_turSecimi.DataSource = okuyucu;
                    cbox_turSecimi.DataBind(); //Veriileri eşitler.
                    okuyucu.Close();
                    baglanti.Close();
                }
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //Satıcı değilse giris yapmaya yönlendirir.
            }
        }

        protected void btn_ekle_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
            SqlCommand sqlCommand_YemekVerileriEkle = new SqlCommand("exec up_YemeklerTablosunaEklemeYap @tur, @yemek_isim, @kullanici_adi, @fiyat, @satici_yorum, @resim", baglanti); //Yemeklere yeni bir kayıt ekledik.
            
            sqlCommand_YemekVerileriEkle.Parameters.AddWithValue("@tur",Convert.ToString(cbox_turSecimi.SelectedValue));
            sqlCommand_YemekVerileriEkle.Parameters.AddWithValue("@yemek_isim",txt_yemekIsim.Text);
            sqlCommand_YemekVerileriEkle.Parameters.AddWithValue("@kullanici_adi", Session["Nickname"].ToString());
            sqlCommand_YemekVerileriEkle.Parameters.AddWithValue("@fiyat", txt_fiyat.Text);
            sqlCommand_YemekVerileriEkle.Parameters.AddWithValue("@satici_yorum", txt_aciklama.Text);
            sqlCommand_YemekVerileriEkle.Parameters.AddWithValue("@resim", txt_resimLink.Text);
            
            sqlCommand_YemekVerileriEkle .ExecuteNonQuery();
            baglanti.Close();

            Response.Write("<script>alert('Ekleme talebiniz onaylanmak üzere yola çıktı!');</script>"); //Bildirim mesajı verdik.
            txt_yemekIsim.Text = "";
            txt_fiyat.Text = "";
            txt_aciklama.Text = "";
            txt_resimLink.Text = "";
        }
    }
}