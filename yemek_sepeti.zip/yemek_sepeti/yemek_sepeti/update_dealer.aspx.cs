﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class update_dealer : System.Web.UI.Page
    {
        int guncellenecek_id;
        string kullanici_adi;
        string sifre;
        string isim;
        string mail;
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isAdmin"]) == true) //Giris Yapan admin mi kontrol ediyoruz
            {
                guncellenecek_id = Convert.ToInt32(Request.QueryString["ID"]); //Seçili satıcı id si gelir

                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_KullaniciyiGetir = new SqlCommand("select Satici_KullaniciAdi,Satici_Sifre,Satici_İsmi,Satici_Mail from tbl_saticilar where Satici_ID = @Pid", baglanti); //Satıcının bilgileri gelir.
                sqlCommand_KullaniciyiGetir.Parameters.AddWithValue("@Pid", guncellenecek_id);
                SqlDataReader okuyucu = sqlCommand_KullaniciyiGetir.ExecuteReader();
                while (okuyucu.Read())
                {//Veriler değişkenlere atılır.
                    kullanici_adi = okuyucu[0].ToString();
                    sifre = okuyucu[1].ToString();
                    isim = okuyucu[2].ToString();
                    mail = okuyucu[3].ToString();
                }
                okuyucu.Close();
                baglanti.Close();

                if (Page.IsPostBack == false) //Sadece sayfa ilk çalıştığında çalışacak kısım.
                {
                    txt_nickname.Text = kullanici_adi;
                    txt_password.Text = sifre;
                    txt_name.Text = isim;
                    txt_mail.Text = mail;
                }


            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //admin değilse giriş yapmaya gönderiyoruz.
            }
        }

        protected void Button1_Click(object sender, EventArgs e) //Satıcıyı güncelleme butonu
        {
            SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
            SqlCommand sqlCommand_KullaniciGuncelle = new SqlCommand("update tbl_saticilar set Satici_Sifre = @Ppassword, Satici_İsmi = @Pname, Satici_Mail = @Pmail where Satici_ID = @Pid", baglanti); //Satıcının bilgilerini girdiği textlerden aldığımız verilerle güncelleriz.
            sqlCommand_KullaniciGuncelle.Parameters.AddWithValue("@Ppassword", txt_password.Text);
            sqlCommand_KullaniciGuncelle.Parameters.AddWithValue("@Pname", txt_name.Text);
            sqlCommand_KullaniciGuncelle.Parameters.AddWithValue("@Pmail", txt_mail.Text);
            sqlCommand_KullaniciGuncelle.Parameters.AddWithValue("@Pid", guncellenecek_id);
            sqlCommand_KullaniciGuncelle.ExecuteNonQuery();
            baglanti.Close();
            Response.Redirect("Admin_Satici_Guncelle.aspx"); //Admin müşteri güncelleme sayfasına gider.
        }
    }
}