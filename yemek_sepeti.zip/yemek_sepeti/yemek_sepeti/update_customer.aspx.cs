﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class update_customer : System.Web.UI.Page
    {
        int guncellenecek_id;
        string kullanici_adi;
        string sifre;
        string isimSoyisim;
        string mail;
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isAdmin"]) == true) //Giris Yapan admin mi kontrol ediyoruz
            {
                guncellenecek_id = Convert.ToInt32(Request.QueryString["ID"]); //Seçili müşteri id si gelir

                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_KullaniciyiGetir = new SqlCommand("select Musteri_KullaniciAdi,Musteri_Sifre,Musteri_IsimSoyisim,Musteri_Mail from tbl_musteriler where Musteri_ID = @Pid", baglanti); //Müşterinin bilgileri gelir.
                sqlCommand_KullaniciyiGetir.Parameters.AddWithValue("@Pid", guncellenecek_id);
                SqlDataReader okuyucu = sqlCommand_KullaniciyiGetir.ExecuteReader();
                while (okuyucu.Read())
                {//Veriler değişkenlere atılır.
                    kullanici_adi = okuyucu[0].ToString();
                    sifre = okuyucu[1].ToString();
                    isimSoyisim = okuyucu[2].ToString();
                    mail = okuyucu[3].ToString();
                }
                okuyucu.Close();
                baglanti.Close();

                if (Page.IsPostBack == false) //Sadece sayfa ilk kez çalıştığında çalışacak kısım
                {
                    txt_nickname.Text = kullanici_adi;
                    txt_password.Text = sifre;
                    txt_name.Text = isimSoyisim;
                    txt_mail.Text = mail;
                }


            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //admin değilse giriş yapmaya gönderiyoruz.
            }
        }

        protected void Button1_Click(object sender, EventArgs e) //Güncelleme butonu
        {
            SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
            SqlCommand sqlCommand_KullaniciGuncelle = new SqlCommand("update tbl_musteriler set Musteri_Sifre = @Ppassword, Musteri_IsimSoyisim = @Pname, Musteri_Mail = @Pmail where Musteri_ID = @Pid", baglanti); //Müşterinin bilgilerini girdiği textlerden aldığımız verilerle güncelleriz.
            sqlCommand_KullaniciGuncelle.Parameters.AddWithValue("@Ppassword", txt_password.Text);
            sqlCommand_KullaniciGuncelle.Parameters.AddWithValue("@Pname", txt_name.Text);
            sqlCommand_KullaniciGuncelle.Parameters.AddWithValue("@Pmail", txt_mail.Text);
            sqlCommand_KullaniciGuncelle.Parameters.AddWithValue("@Pid", guncellenecek_id);
            sqlCommand_KullaniciGuncelle.ExecuteNonQuery();
            baglanti.Close();
            Response.Redirect("Admin_Musteri_Guncelle.aspx"); //Admin müşteri güncelleme sayfasına gider.
        }
    }
}