﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class view_comment : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isCustomer"])) //Giris Yapan müşteri mi kontrol ediyoruz
            {
                int yemek_id = Convert.ToInt32(Request.QueryString["ID"]); //Seçili yemeğin idsi gelir
                SqlConnection baglanti = baglanti_cls.Baglan();
                SqlCommand sqlCommand_YorumlariGetir = new SqlCommand("select Yemek_ID,Alici_KullaniciAdi,Yemek_Yorumu from tbl_siparişler where Yemek_ID = @Pyemek_id and Yemek_Yorumu is not null", baglanti); //Seçili yemeğin verileri gelir.
                sqlCommand_YorumlariGetir.Parameters.AddWithValue("@Pyemek_id", yemek_id);
                SqlDataReader okuyucuTeslimOlan = sqlCommand_YorumlariGetir.ExecuteReader();
                DataList1.DataSource = okuyucuTeslimOlan;
                DataList1.DataBind(); //Veriler eşitlenir.
                okuyucuTeslimOlan.Close();
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //Müşteri değilse giriş yapmaya gönderiyoruz.
            }
        }
    }
}