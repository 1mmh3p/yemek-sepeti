﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class admin_msg_delete : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isAdmin"]) == true)  //Giris Yapan admin mi kontrol ediyoruz
            {
                int silinecek_msg = Convert.ToInt32(Request.QueryString["ID"]); //Seçili mesajın idsi gelir
                SqlConnection baglanti = baglanti_cls.Baglan();
                SqlCommand sqlCommand_MesajiSil = new SqlCommand("delete from tbl_admin_iletisim where Mesaj_ID = @Pid", baglanti); //Seçili mesajı siliyoruz
                sqlCommand_MesajiSil.Parameters.AddWithValue("@Pid", silinecek_msg);
                sqlCommand_MesajiSil.ExecuteNonQuery();
                baglanti.Close();

                Response.Redirect("Mesaj_Admin.aspx"); //Mesaj sayfasına geri dönüyoruz
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //admin değilse giris yapmaya yönlendirir.
            }
            
        }
    }
}