﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class admin_meal_confirmation : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isAdmin"]) == true) //Giris Yapan admin mi kontrol ediyoruz
            {
                int onaylanacak_yemek = Convert.ToInt32(Request.QueryString["ID"]); //Seçili yemeğin idsi gelir
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_YemekOnayla = new SqlCommand("update tbl_yemekler set Onay = 1 where Yemek_ID = @Pid", baglanti); //Yemek onaylanır
                sqlCommand_YemekOnayla.Parameters.AddWithValue("@Pid", onaylanacak_yemek); //Onaylanacak yemek idsi gonderilir.

                sqlCommand_YemekOnayla.ExecuteNonQuery();
                baglanti.Close();

                Response.Redirect("Onay_Admin.aspx"); //Onay admin sayfasına geri dönülür.
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //admin değilse giris yapmaya yönlendirir. 
            }
        }
    }
}