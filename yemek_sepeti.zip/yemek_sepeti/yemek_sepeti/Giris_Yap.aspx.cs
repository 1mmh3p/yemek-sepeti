﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class Giris_Yap : System.Web.UI.Page
    {
        string kullanici_adi;
        SQLConnection baglanti_cls = new SQLConnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Page.IsPostBack == false) //Sadece sayfa ilk yüklendiğinde çalışacak kısım.
            {
                cbox_tur.Items.Add("Müşteri");
                cbox_tur.Items.Add("Şirket");
                cbox_tur.Items.Add("Admin");
            }
        }

        protected void btn_girisYap_Click(object sender, EventArgs e)
        {
            if (cbox_tur.SelectedValue == "Müşteri" && txt_kullaniciAdi.Text != "" && txt_sifre.Text != "") //müşteri ve boş box kontrolü
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_GirisYap = new SqlCommand("select Musteri_KullaniciAdi from tbl_musteriler where Musteri_KullaniciAdi = @Pnickname and Musteri_Sifre = @Ppassword", baglanti); //Şifre ile kullanıcı adına göre kullanıcı adını veri tabanından çekiyoruz. Kullanıcı adının olup olmadığını kontrol etmek için.
                sqlCommand_GirisYap.Parameters.AddWithValue("@Pnickname",txt_kullaniciAdi.Text);
                sqlCommand_GirisYap.Parameters.AddWithValue("@Ppassword", txt_sifre.Text);
                SqlDataReader okuyucu = sqlCommand_GirisYap.ExecuteReader();
                int dogrulukKontrol = 0;
                while (okuyucu.Read())
                {
                    dogrulukKontrol += 1; //Kullanıcı adı varsa dogruluk kontrolu 1 arttırıyoruz.
                    kullanici_adi = okuyucu[0].ToString(); //Kullanıcı adını kaydediyoruz.
                }
                baglanti.Close();
                
                if(dogrulukKontrol > 0) //kullanıcı adı varsa
                {
                    Session["isCustomer"]=true; //Kullanıcıyı müşteri olarak tanımlıyoruz.
                    Session["Nickname"] = kullanici_adi; //Kullanıcı adını session içinde kaydediyoruz. Diğer sayfalarda da erişmek için.
                    Response.Redirect("Siparis_Ver.aspx"); //Sipariş ver sayfasına gönderiyoruz.
                }
                else
                {
                    Response.Write("<script>alert('Tekrar Deneyiniz!');</script>"); //Kullanıcı adı yoksa tekrar deneyiniz yazdırıyoruz.
                    txt_kullaniciAdi.Text = "";
                    txt_sifre.Text = "";
                }
            }

            
            else if (cbox_tur.SelectedValue == "Şirket" && txt_kullaniciAdi.Text != "" && txt_sifre.Text != "") //şirketse ve box boşluk kontrolü
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_GirisYap = new SqlCommand("select Satici_KullaniciAdi from tbl_saticilar where Satici_KullaniciAdi = @Pnickname and Satici_Sifre = @Ppassword", baglanti); //Şifre ile kullanıcı adına göre kullanıcı adını veri tabanından çekiyoruz. Kullanıcı adının olup olmadığını kontrol etmek için.
                sqlCommand_GirisYap.Parameters.AddWithValue("@Pnickname", txt_kullaniciAdi.Text);
                sqlCommand_GirisYap.Parameters.AddWithValue("@Ppassword", txt_sifre.Text);
                SqlDataReader okuyucu = sqlCommand_GirisYap.ExecuteReader();
                
                int dogrulukKontrol = 0;
                while (okuyucu.Read())
                {
                    dogrulukKontrol += 1; //Kullanıcı adı varsa dogruluk kontrolu 1 arttırıyoruz.
                    kullanici_adi = okuyucu[0].ToString(); //Kullanıcı adını kaydediyoruz.
                }
                baglanti.Close();

                if (dogrulukKontrol > 0) //kullanıcı adı varsa
                {
                    Session["isDealer"] = true; //Kullanıcıyı satıcı olarak tanımlıyoruz.
                    Session["Nickname"] = kullanici_adi; //Kullanıcı adını session içinde kaydediyoruz. Diğer sayfalarda da erişmek için.
                    Response.Redirect("Yemek_Ekleme.aspx"); //Yemek ekleme sayfasına yönlendiriyoruz.
                }
                else
                {
                    Response.Write("<script>alert('Tekrar Deneyiniz!');</script>"); //Kullanıcı adı yoksa tekrar deneyiniz yazdırıyoruz.
                    txt_kullaniciAdi.Text = "";
                    txt_sifre.Text = "";
                }
            }

            else if (cbox_tur.SelectedValue == "Admin" && txt_kullaniciAdi.Text != "" && txt_sifre.Text != "") //adminse ve box boşluk kontrolü
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_GirisYap = new SqlCommand("select * from tbl_admin_kayitlari where Admin_KullaniciAdi = @Pnickname and Admin_Sifre = @Ppassword", baglanti); //Şifre ile kullanıcı adına göre kullanıcı adını veri tabanından çekiyoruz. Kullanıcı adının olup olmadığını kontrol etmek için.
                sqlCommand_GirisYap.Parameters.AddWithValue("@Pnickname", txt_kullaniciAdi.Text);
                sqlCommand_GirisYap.Parameters.AddWithValue("@Ppassword", txt_sifre.Text);
                SqlDataReader okuyucu = sqlCommand_GirisYap.ExecuteReader();
                int dogrulukKontrol = 0;
                while (okuyucu.Read())
                {
                    dogrulukKontrol += 1; //Kullanıcı adı varsa dogruluk kontrolu 1 arttırıyoruz.
                    kullanici_adi = okuyucu[0].ToString(); //Kullanıcı adını kaydediyoruz.
                }
                baglanti.Close();

                if (dogrulukKontrol > 0) //kullanıcı adı varsa
                {
                    Session["isAdmin"] = true; //Kullanıcıyı admin olarak tanımlıyoruz.
                    Session["Nickname"] = kullanici_adi; //Kullanıcı adını session içinde kaydediyoruz. Diğer sayfalarda da erişmek için.
                    Response.Redirect("Admin_Kayit_Datalari.aspx"); //admin kayıt datalrına yönlendiriyoruz.
                }
                else
                {
                    Response.Write("<script>alert('Tekrar Deneyiniz!');</script>"); //Kullanıcı adı yoksa tekrar deneyiniz yazdırıyoruz.
                    txt_kullaniciAdi.Text = "";
                    txt_sifre.Text = "";
                }
            }
        }
    }
}