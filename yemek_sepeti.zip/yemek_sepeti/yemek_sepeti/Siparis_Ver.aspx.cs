﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class yemekler : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.

        protected void Page_Load(object sender, EventArgs e)
        {
            if(Convert.ToBoolean(Session["isCustomer"]) == true) //Giris Yapan müşteri mi kontrol ediyoruz
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_YemekList = new SqlCommand("up_YemeklerVeSaticilariniGetirOnayaGore @onay = @Ponay", baglanti); //Adminin onayladığı yemekleri getirir.
                sqlCommand_YemekList.Parameters.AddWithValue("@Ponay", true);

                SqlDataReader okuyucu = sqlCommand_YemekList.ExecuteReader();
                DataList1.DataSource = okuyucu;
                DataList1.DataBind(); //Verileri eşler.
                okuyucu.Close();
                baglanti.Close();
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //Müşteri değilse giriş yapmaya gönderiyoruz.
            }
        }

        protected void btn_ara_Click(object sender, EventArgs e)
        {
            if(txt_arama.Text == "") //Arama çubuğu boşsa
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_YemekList = new SqlCommand("up_YemeklerVeSaticilariniGetirOnayaGore @onay = @Ponay", baglanti); //Onaylı bütun yemekleri getirir.
                sqlCommand_YemekList.Parameters.AddWithValue("@Ponay", true);

                SqlDataReader okuyucu = sqlCommand_YemekList.ExecuteReader();
                DataList1.DataSource = okuyucu;
                DataList1.DataBind(); //Verileri eşler.
                okuyucu.Close();
                baglanti.Close();
            }
            else
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_YemekList = new SqlCommand("up_YemeklerVeSaticilariniGetirOnayaVeYemekİsmineGore @Ponay, @Pyemek_ismi", baglanti); //Yemek ismine göre onaylı yemekleri getirir.
                sqlCommand_YemekList.Parameters.AddWithValue("@Ponay", true);
                sqlCommand_YemekList.Parameters.AddWithValue("@Pyemek_ismi", txt_arama.Text);

                SqlDataReader okuyucu = sqlCommand_YemekList.ExecuteReader();
                DataList1.DataSource = okuyucu;
                DataList1.DataBind(); //Verileri eşler.
                okuyucu.Close();
                baglanti.Close();
            }
            
        }

        protected void btn_sirketAra_Click(object sender, EventArgs e)
        {
            if (txt_sirketAra.Text == "") //Arama çubuğu boşsa
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_YemekList = new SqlCommand("up_YemeklerVeSaticilariniGetirOnayaGore @onay = @Ponay", baglanti); //Onaylı bütun yemekleri getirir.
                sqlCommand_YemekList.Parameters.AddWithValue("@Ponay", true);

                SqlDataReader okuyucu = sqlCommand_YemekList.ExecuteReader();
                DataList1.DataSource = okuyucu;
                DataList1.DataBind(); //Verileri eşler.
                okuyucu.Close();
                baglanti.Close();
            }
            else
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_YemekList = new SqlCommand("select Yemek_ID, Yemek_Türü, Yemek_İsmi, Yemek_Resmi, Yemek_Fiyatı, Yemek_Açıklaması, Yemek_Puanı, Satici_İsmi, Satici_Şehir, Satici_Tel,Yemek_OylayanSayisi from tbl_yemekler inner join tbl_saticilar on tbl_yemekler.Satici_KullaniciAdi = tbl_saticilar.Satici_KullaniciAdi where Satici_İsmi = @satici_ismi and Onay = @Ponay", baglanti); //Onaylı bütun yemekleri getirir.
                sqlCommand_YemekList.Parameters.AddWithValue("@Ponay", true);
                sqlCommand_YemekList.Parameters.AddWithValue("@satici_ismi", txt_sirketAra.Text);

                SqlDataReader okuyucu = sqlCommand_YemekList.ExecuteReader();
                DataList1.DataSource = okuyucu;
                DataList1.DataBind(); //Verileri eşler.
                okuyucu.Close();
                baglanti.Close();
            }
        }
    }
}