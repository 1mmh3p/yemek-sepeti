﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class buy_meal : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        string satici_kullaniciAdi;
        string alici_kullaniciAdi;
        string siparis_zamani;
        string yemek_turu;
        string yemek_ismi;
        string yemek_fiyati;
        string yemek_id;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isCustomer"])==true) //Giris Yapan müşteri mi kontrol ediyoruz
            {
                int eklenecek_siparis = Convert.ToInt32(Request.QueryString["ID"]); //Seçili yemeğin idsi gelir
                alici_kullaniciAdi = Convert.ToString(Session["Nickname"]); //Kullanıcının kullanıcı adını alır

                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz

                SqlCommand sqlCommand_ZamaniGetir = new SqlCommand("select convert(datetime, getdate(), 24)", baglanti); //Stın alma tarihi getiriyoruz
                SqlDataReader okuyucu = sqlCommand_ZamaniGetir.ExecuteReader();
                while (okuyucu.Read())
                {
                    siparis_zamani = okuyucu[0].ToString(); //Tarihi kaydediyoruz.
                }
                okuyucu.Close();

                SqlCommand sqlCommand_YemegiGetir = new SqlCommand("select Satici_KullaniciAdi, Yemek_Türü, Yemek_İsmi, Yemek_Fiyatı, Yemek_ID from tbl_yemekler where Yemek_ID = @Pid", baglanti); //Yemekler tablosundan yemeğin bilgilerini getiriyoruz.
                sqlCommand_YemegiGetir.Parameters.AddWithValue("@Pid",eklenecek_siparis);
                SqlDataReader okuyucu1 = sqlCommand_YemegiGetir.ExecuteReader();
                while (okuyucu1.Read())
                {
                    satici_kullaniciAdi = okuyucu1[0].ToString(); //kullanıcı adını kaydediyoruz.
                    yemek_turu = okuyucu1[1].ToString(); //Yemek türünü kaydediyoruz.
                    yemek_ismi = okuyucu1[2].ToString(); // Yemek ismini kaydediyoruz.
                    yemek_fiyati = okuyucu1[3].ToString(); //Yemek fiyatını kaydediyoruz.
                    yemek_id = okuyucu1[4].ToString(); //Yemek idsini kaydediyoruz.
                }
                okuyucu1.Close();

                SqlCommand sqlCommand_SatinAl = new SqlCommand("insert into tbl_siparişler(Yemek_ID,Satici_KullaniciAdi,Alici_KullaniciAdi,Yemek_Türü,Yemek_İsmi,Yemek_Fiyatı,Siparis_Durumu,Siparis_Zamani) values(@Pyemek_id, @PsaticiKullaniciAdi, @PaliciKullaniciAdi, @Ptür, @Pisim, @Pfiyat, @Pdurum,@Psiparis_zamani)", baglanti); //Siparişler tablosuna siparişi ekliyoruz.
                sqlCommand_SatinAl.Parameters.AddWithValue("@Pyemek_id", yemek_id);
                sqlCommand_SatinAl.Parameters.AddWithValue("@PsaticiKullaniciAdi", satici_kullaniciAdi);
                sqlCommand_SatinAl.Parameters.AddWithValue("@PaliciKullaniciAdi", alici_kullaniciAdi);
                sqlCommand_SatinAl.Parameters.AddWithValue("@Ptür", yemek_turu);
                sqlCommand_SatinAl.Parameters.AddWithValue("@Pisim", yemek_ismi);
                sqlCommand_SatinAl.Parameters.AddWithValue("@Pfiyat", yemek_fiyati);
                sqlCommand_SatinAl.Parameters.AddWithValue("@Pdurum", "Siparişin Onaylanması Bekleniyor.");
                sqlCommand_SatinAl.Parameters.AddWithValue("@Psiparis_zamani", siparis_zamani);
                sqlCommand_SatinAl.ExecuteNonQuery();
                baglanti.Close();
                Response.Redirect("Siparisler_Kullanici.aspx"); //Siparişler sayfasına gidiyoruz.
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //Müşteri değilse giriş yapmaya gönderiyoruz.
            }
        }
    }
}